// This specific pattern of parenthesis and curly braces 
// make this function fire when the document is loaded.
// This specific function binds HTML elements and their events
//  to event-handling functions.
(function bindEvents(){
    console.log('Binding events...');
    document.getElementById('clickableButton').addEventListener('click', buttonClicked);
})();

function buttonClicked(){
    console.log('The button has been clicked!')
    alert('Clicked')
}