document.getElementById('ClickableButton').addEventListener('click', ButtonClicked());

function ButtonClicked(){
    alert('Clicked')
}